Data are taken from http://www.amstat.org/publications/jse/jse_data_archive.htm
